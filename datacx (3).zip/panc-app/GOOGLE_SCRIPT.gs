/* ============================================================
   Data cx — script de la planilla (método gratis)
   
   Pegá TODO este código en la planilla de Google:
   Extensiones → Apps Script → borrar lo que haya → pegar esto.
   
   1) Cambiá la CLAVE de abajo por una propia (la vas a pegar
      también en la app; es lo que impide que un desconocido
      con la URL escriba en la planilla).
   2) Implementar → Nueva implementación → tipo "Aplicación web"
      → Ejecutar como: "Yo" → Acceso: "Cualquier persona"
      → Implementar → copiar la URL (termina en /exec).
   3) Esa URL + la clave van en Data cx, en
      "Conectar a una planilla de Google".
   ============================================================ */

var CLAVE = 'CAMBIAME-por-una-clave-del-servicio';

function doPost(e) {
  var p;
  try { p = JSON.parse(e.postData.contents); } catch (err) { return out({ error: 'json' }); }
  if (p.token !== CLAVE) return out({ error: 'token' });

  /* Cada carpeta de Data cx vive en su propia pestaña de este libro.
     Si la pestaña no existe todavía, se crea sola. */
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var hoja = p.hoja
    ? (ss.getSheetByName(p.hoja) || ss.insertSheet(p.hoja))
    : ss.getSheets()[0];

  if (p.action === 'pull') {
    return out({ values: hoja.getDataRange().getValues() });
  }

  if (p.action === 'push') {
    var rows = p.rows || [];
    /* Todas las filas al mismo ancho, que setValues es estricto. */
    var ancho = rows.reduce(function (m, r) { return Math.max(m, r.length); }, 0);
    rows = rows.map(function (r) { while (r.length < ancho) r.push(''); return r; });
    hoja.clearContents();
    if (rows.length) hoja.getRange(1, 1, rows.length, ancho).setValues(rows);
    return out({ ok: true, n: rows.length - 1 });
  }

  return out({ error: 'accion desconocida' });
}

function out(o) {
  return ContentService.createTextOutput(JSON.stringify(o))
    .setMimeType(ContentService.MimeType.JSON);
}
